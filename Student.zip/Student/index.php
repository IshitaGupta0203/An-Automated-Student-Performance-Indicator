<!DOCTYPE html>
<html>
<head>
  <title> GGSP</title>
  <?php require_once 'head.php';?>
</head>
<body>

<?php require_once 'menu.php';?>
   <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image:url(img/1.jpg) ;">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          
        </div>
        </div>
      </div>

      
      <div class="slider-item" style="background-image:url(img/2.jpg); background-size: 1400px; ">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          
        </div>
        </div>
      </div>

       <div class="slider-item" style="background-image:url(img/4.jpg); background-size: 1400px; ">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-8 text-center ftco-animate">
           
            
          </div>
        </div>
        </div>
      </div>


    </section>

<br>



</section>
<!--Projects section v.4-->

  <div class="row   ftco-animate" style="background-color: #757575">
  <div class="col-md-2"></div>

  <div class="col-md-7">
    <br>
    <h1 class="text-center " style="color: white;font-size: 40px">&nbsp;<b>Watch Our Campus Video</b></h1>


    <br>
     <iframe width="700" height="315" src="https://www.youtube.com/embed/FDSZxuK-11Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
     <div class="col-md-3">
       <br>
     
     </div>
   </div></div>

  <section class="testimonial-wthree  ftco-animate "> 
  <div class="container">
    <h1 class="text-center" style="color: #1c2a48 ;font-size: 40px"><b>Vision</b> </h1>
    <div id="myCarousel" class="carousel slide slideanim" data-ride="carousel" data-interval="3000" data-pause="none">
      <!-- Indicators -->
     
      <!-- Wrapper for slides -->
     
        <div class="item active">
          <br><br>
          
          <p style="color: #1C2331;font-size: 20px">

An Institute striving for excellence in providing transformative Education and enhancing multidisciplinary skills for developing Intellectual, Innovative and Quality Technician / Engineer / Entrepreneur  which will benefit the Society and the Industrial challenges </p>

          <br>
        </div>
        
        
      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
       
        
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
       
      </a>
    </div>
  </div>
</section>   


<br>

 

<br><br>
<?php require_once 'footer.php';?>
</body>
</html>
