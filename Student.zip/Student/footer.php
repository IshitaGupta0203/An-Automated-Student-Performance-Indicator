 
 
<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5">
              
              <a href="HOME"><img src="img/logog.jpeg" height="150px" width="180px"></a>
              <br> <p style="color: white;font-family:Trebuchet MS;" >
                                            Khalsa Educational Complex ,<br>
                                            Indira Nagar,Pardhari Road,<br>
                                             Nashik (MH), 
                                            India - 422009<br></a></li>
                                        </p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2" style="font-family:Trebuchet MS;"> Have any Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text" style="font-family:Trebuchet MS;">Khalsa Educational Complex, Guru Gobind Singh Marg,Wadala-Parhardi Road, Indira Nagar Annexe,Nashik – 422009</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text" style="font-family:Trebuchet MS;">+ 0253-2372766, 2372666</span></a></li>
                  <li><a href="mailto:info@wisdomhigh.org"><span class="icon icon-envelope"></span><span class="text" style="font-family:Trebuchet MS;">ggsf.nashik@ggsf.edu.in</span></a></li>
                </ul>
              </div>
            </div>
          </div>
         

          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5 ml-md-4">
              <h2 class="ftco-heading-2" style="font-family:Trebuchet MS;">&nbsp;Our Institutes</h2>
              <ul class="list-unstyled">
        <h4 style="font-family:Trebuchet MS; color: white">&nbsp;Guru Gobind Singh Public School</h4>
<br>
<h4 style="font-family:Trebuchet MS; color: white">&nbsp;Guru Gobind Singh Polytechnic </h4>
                 <br>
       <h4 style="font-family:Trebuchet MS; color: white">&nbsp;Guru Gobind Singh Foundation </h4>
      
      </li>


             </ul>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2" style="font-family:Trebuchet MS;">&nbsp;&nbsp;&nbsp;Subscribe Us!</h2>
              <form action="#" class="subscribe-form">
                <div class="form-group">
                  <input type="text" class="form-control mb-2 text-center" placeholder="Enter email address">
                  <input type="submit" value="Subscribe" class="form-control submit px-3">
                </div>
              </form>
            </div>
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2 mb-0" style="font-family:Trebuchet MS;">&nbsp;&nbsp;Connect With Us</h2>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="https://twitter.com/GGSP"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/GGSP"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |  <i class="icon-heart" aria-hidden="true"></i>  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    




<!--script links-->

 <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

  <!--wow script-->
   <script src="wow/js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
    
 <!-- bootstrap scripts-->

 